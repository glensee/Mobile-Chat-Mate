# Chess
A Chess game written with Jetpack Compose.

Ported from [https://github.com/nicklockwood/Chess](https://github.com/nicklockwood/Chess).

Work In Progress

## Screenshots

![Home](/screenshots/shot1.png)

## TODO
- Animating pieces
- Better AI (the current one is really terrible, effectively random)
